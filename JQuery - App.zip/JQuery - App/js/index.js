$( document ).ready(function() {
    console.log( "ready!" );

    loadFeatureApps();
    loadJSON2();
    loadJSON3();

});


function loadFeatureApps() {
    $.getJSON( "data/features.json", function( data ) {
      var items = [];
      var count = 0;
      $.each( data, function( key, obj ) {
        item = "";        
        count ++;
        if(count == 2) {
            item = '<div class="row">';
        }
        item = item + '<div class="col-lg-6"><span>'+obj.name+'</span></div>';
        if(count == 2) {
            item = item + '</div>';
            count = 0;  
        }
        
        items.push(item);
        item = "";
      });
     $(".featuresRow").html(items);
    });
}

function loadJSON2() {

    $.getJSON( "data/2nd-ajax.json", function( data ) {
      var items = [];
      items.push("<div>");
      $.each( data, function( key, obj ) {
        items.push("<span>"+obj.name+"</span> | ");
      });
      items.push("</div>");
     $(".2ndRow").html(items);
    });
}


function loadJSON3() {
    $.getJSON( "data/3nd-ajax.json", function( data ) {
      var items = [];
      var count = 0;
      $.each( data, function( key, obj ) {
        item = "";        
        count ++;
        if(count == 2) {
            item = '<div class="row">';
        }
        item = item + '<div class="col-lg-6"><span>'+obj.name+'</span></div>';
        if(count == 2) {
            item = item + '</div>';
            count = 0;  
        }
        items.push(item);
        item = "";
      });
     $(".3rdRow").html(items);
    });
}
